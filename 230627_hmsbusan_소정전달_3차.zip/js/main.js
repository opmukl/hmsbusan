(function ($) {
  main = {
    init: function () {
      this.section1();
      this.section2();
      this.section3();
    },
    //모달 별 스크립트
    section1: function () {
      $(".text1").on({
        click: function () {
          $("#mask").addClass("active");
          $("#hyundai_motostudio_busan").addClass("active");
        }
      });
      $(".text2").on({
        click: function () {
          $("#mask").addClass("active");
          $("#home_stories").addClass("active");
        }
      });
      $(".text3").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section1_ioniq").addClass("active");
        }
      });
      $(".text4").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section2_home_stories").addClass("active");
        }
      });
      $(".text5").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section2-1_resiential").addClass("active");
        }
      });
      $(".text6").on({
        click: function () {
          $("#mask").addClass("active");
          $("#jasper_morrison").addClass("active");
        }
      });
      $(".text7").on({
        click: function () {
          $("#mask").addClass("active");
          $("#ikea").addClass("active");
        }
      });
      $(".text8").on({
        click: function () {
          $("#mask").addClass("active");
          $("#elii").addClass("active");
        }
      });
      $(".text9").on({
        click: function () {
          $("#mask").addClass("active");
          $("#assemble").addClass("active");
        }
      });
      $(".text10").on({
        click: function () {
          $("#mask").addClass("active");
          $("#brandlhuber_emde").addClass("active");
        }
      });
      $(".text11").on({
        click: function () {
          $("#mask").addClass("active");
          $("#karl_lagerfeld").addClass("active");
        }
      });
      $(".text12").on({
        click: function () {
          $("#mask").addClass("active");
          $("#michael_graves").addClass("active");
        }
      });
      $(".text13").on({
        click: function () {
          $("#mask").addClass("active");
          $("#kurokawa").addClass("active");
        }
      });
      $(".text14").on({
        click: function () {
          $("#mask").addClass("active");
          $("#claude_parent").addClass("active");
        }
      });
      $(".text15").on({
        click: function () {
          $("#mask").addClass("active");
          $("#andy_warhol").addClass("active");
        }
      });
      $(".text16").on({
        click: function () {
          $("#mask").addClass("active");
          $("#stanley_klein").addClass("active");
        }
      });
      $(".text17").on({
        click: function () {
          $("#mask").addClass("active");
          $("#jacqes_tati").addClass("active");
        }
      });
      $(".text18").on({
        click: function () {
          $("#mask").addClass("active");
          $("#lina_bo_bardi").addClass("active");
        }
      });
      $(".text19").on({
        click: function () {
          $("#mask").addClass("active");
          $("#bernard_rudofsky").addClass("active");
        }
      });
      $(".text20").on({
        click: function () {
          $("#mask").addClass("active");
          $("#finn_juhl").addClass("active");
        }
      });
      $(".text21").on({
        click: function () {
          $("#mask").addClass("active");
          $("#josef_frank").addClass("active");
        }
      });
      $(".text22").on({
        click: function () {
          $("#mask").addClass("active");
          $("#cecil_beaton").addClass("active");
        }
      });
      $(".text23").on({
        click: function () {
          $("#mask").addClass("active");
          $("#ludwig_mies_van_der_rohe").addClass("active");
        }
      });
      $(".text24").on({
        click: function () {
          $("#mask").addClass("active");
          $("#adolf_loos").addClass("active");
        }
      });
      $(".text25").on({
        click: function () {
          $("#mask").addClass("active");
          $("#margarete_schutte").addClass("active");
        }
      });
      $(".text26").on({
        click: function () {
          $("#mask").addClass("active");
          $("#ernst_may_und").addClass("active");
        }
      });
      $(".text27").on({
        click: function () {
          $("#mask").addClass("active");
          $("#elsie_de_wolfe").addClass("active");
        }
      });
      $(".text28").on({
        click: function () {
          $("#mask").addClass("active");
          $("#verner_panton").addClass("active");
        }
      });
      $(".text29").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section2-2_interior").addClass("active");
        }
      });
      $(".text30").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section2-3_nature").addClass("active");
        }
      });
      $(".text31").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section2-4_birth").addClass("active");
        }
      });
      $(".text32").on({
        click: function () {
          $("#mask").addClass("active");
          $("#jmorrison_video").addClass("active");
        }
      });
      $(".text33").on({
        click: function () {
          $("#mask").addClass("active");
          $("#days_of_summer_video").addClass("active");
        }
      });
      $(".text34").on({
        click: function () {
          $("#mask").addClass("active");
          $("#fireplace_video").addClass("active");
        }
      });
      $(".text35").on({
        click: function () {
          $("#mask").addClass("active");
          $("#yojigen_video").addClass("active");
        }
      });
      $(".text36").on({
        click: function () {
          $("#mask").addClass("active");
          $("#themroc_video").addClass("active");
        }
      });
      $(".text37").on({
        click: function () {
          $("#mask").addClass("active");
          $("#andy_warhol_video").addClass("active");
        }
      });
      $(".text38").on({
        click: function () {
          $("#mask").addClass("active");
          $("#nbc_video").addClass("active");
        }
      });
      $(".text39").on({
        click: function () {
          $("#mask").addClass("active");
          $("#nixon_video").addClass("active");
        }
      });
      $(".text40").on({
        click: function () {
          $("#mask").addClass("active");
          $("#mon_oncle_video").addClass("active");
        }
      });
      $(".text41").on({
        click: function () {
          $("#mask").addClass("active");
          $("#die_frankfurter_video").addClass("active");
        }
      });
      $(".text42").on({
        click: function () {
          $("#mask").addClass("active");
          $("#under_a_flowing_video").addClass("active");
        }
      });
      $(".text43").on({
        click: function () {
          $("#mask").addClass("active");
          $("#home_stories_video").addClass("active");
        }
      });
      $(".text44").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section3_flowing").addClass("active");
        }
      });
      $(".text45").on({
        click: function () {
          $("#mask").addClass("active");
          $("#section4_the_archive").addClass("active");
        }
      });
      $(".text46").on({
        click: function () {
          $("#mask").addClass("active");
          $("#home_stories_museum").addClass("active");
        }
      });
      $(".text47").on({
        click: function () {
          $("#mask").addClass("active");
          $("#main_visual").addClass("active");
        }
      });
      $(".text48").on({
        click: function () {
          initUnderAFlowingField();
        }
      });
      $(".text49").on({
        click: function () {
          initHomeStoriesChronological();
        }
      });
      $(".text50").on({
        click: function () {
          initSection4HomeStories();
        }
      });
      $(".text51").on({
        click: function () {
          inigDoorHanger();
        }
      });
      // 마스크, X버튼 클릭 시
      $(".close_btn:not('.zoom_close_btn'), #mask").on({
        click: function () {
          $("#mask").removeClass("active");
          $(".modal").removeClass("active");
        }
      });
    },
    // 한, 영문 텍스트 변환 스크립트
    section2: function () {
      $(document).ready(function () {
        $(".modal_button").on("click", (e) => {
          let parent = $(e.currentTarget).closest(".inner");
          let lang = $(e.currentTarget).data("lang");

          $(parent).find(".modal_button").removeClass("active");
          $(parent).find(`.modal_button[data-lang=${lang}]`).addClass("active");
          $(parent).find(".img_direct_zoom").removeClass("active");
          $(parent).find(`.img_direct_zoom[data-type=${lang}]`).addClass("active");
          $(parent).find(".img_direct_zoom").trigger("wheelzoom.reset");
        });

        setTimeout(() => {
          $(".img_direct_zoom").wheelzoom();
        }, 1000);
      });
    },
    // IOS, 윈도우 스크롤 바 디자인 스크립트
    section3: function () {
      document.addEventListener("DOMContentLoaded", function () {
        const containers = document.querySelectorAll(".scroll-container");
        containers.forEach(function (container) {
          OverlayScrollbars(container, {
            className: "os-theme-dark",
            scrollbars: {
              visibility: "auto",
              autoHide: "leave"
            }
          });
        });
        // const horizonContainers = document.querySelectorAll(".scroll-container-horizon");
        // containers.forEach(function (horizonContainers) {
        //   OverlayScrollbars(horizonContainers, {
        //     className: "os-theme-dark",
        //     scrollbars: {
        //       visibility: "auto",
        //       autoHide: "leave",
        //     },
        //   });
        // });
      });
    }
  };
  main.init();
})(jQuery);
